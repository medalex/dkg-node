import { kcTools } from 'assertion-tools';
import fs from 'fs/promises';
import path from 'path';
import Command from '../../../command.js';
import {
    OPERATION_ID_STATUS,
    ERROR_TYPE,
    PARANET_ACCESS_POLICY,
    TRIPLE_STORE_REPOSITORIES,
    NETWORK_MESSAGE_TYPES,
    NETWORK_MESSAGE_TIMEOUT_MILLS,
    PRIVATE_ASSERTION_PREDICATE,
    PRIVATE_HASH_SUBJECT_PREFIX,
    MIGRATION_FLAG_PATH,
    COMMAND_PRIORITY,
} from '../../../../constants/constants.js';

class GetCommand extends Command {
    constructor(ctx) {
        super(ctx);
        this.operationIdService = ctx.operationIdService;
        this.ualService = ctx.ualService;
        this.operationService = ctx.getService;
        this.validationService = ctx.validationService;
        this.blockchainModuleManager = ctx.blockchainModuleManager;
        this.paranetService = ctx.paranetService;
        this.tripleStoreService = ctx.tripleStoreService;
        this.networkModuleManager = ctx.networkModuleManager;
        this.shardingTableService = ctx.shardingTableService;
        this.cryptoService = ctx.cryptoService;
        this.messagingService = ctx.messagingService;
        this.tripleStoreModuleManager = ctx.tripleStoreModuleManager;
        this.pendingStorageService = ctx.pendingStorageService;
    }

    async handleError(operationId, blockchain, errorMessage, errorType) {
        await this.operationService.markOperationAsFailed(
            operationId,
            blockchain,
            errorMessage,
            errorType,
        );
        this.operationIdService.emitChangeEvent(
            OPERATION_ID_STATUS.GET.GET_FAILED,
            operationId,
            blockchain,
        );
    }

    /**
     * Executes command and produces one or more events
     * @param command
     */
    async execute(command) {
        const {
            operationId,
            blockchain,
            contract,
            knowledgeCollectionId,
            ual,
            paranetUAL,
            paranetSync,
            contentType,
            includeMetadata,
            paranetNodesAccessPolicy,
            knowledgeAssetId,
            minimumNumberOfNodeReplications,
        } = command.data;

        await this.operationIdService.updateOperationIdStatus(
            operationId,
            blockchain,
            OPERATION_ID_STATUS.GET.GET_VALIDATE_ASSET_START,
        );

        const maxGetRetries = 3;
        const getRetryDelayMs = 5_000;
        let ualValidationPassed = false;
        let ualValidationError = null;

        for (let attempt = 1; attempt <= maxGetRetries; attempt += 1) {
            try {
                // eslint-disable-next-line no-await-in-loop
                const { isValid, errorMessage: valMsg } = await this.validateUAL(
                    operationId,
                    blockchain,
                    contract,
                    knowledgeCollectionId,
                    ual,
                );
                if (isValid) {
                    ualValidationPassed = true;
                    break;
                }
                ualValidationError = valMsg;
            } catch (err) {
                ualValidationError = `UAL validation failed: ${err.message}`;
            }

            if (!ualValidationPassed) {
                try {
                    // eslint-disable-next-line no-await-in-loop
                    const cachedResult = await this._tryCacheFallback(
                        blockchain,
                        contract,
                        knowledgeCollectionId,
                        knowledgeAssetId,
                        ual,
                        operationId,
                        paranetNodesAccessPolicy,
                        contentType,
                    );
                    if (cachedResult) {
                        return cachedResult;
                    }
                } catch (_cacheErr) {
                    // cache fallback also failed, will retry
                }
            }

            if (attempt < maxGetRetries) {
                this.logger.debug(
                    `Get validation/cache attempt ${attempt}/${maxGetRetries} failed for ${ual}, retrying in ${getRetryDelayMs}ms`,
                );
                // eslint-disable-next-line no-await-in-loop
                await new Promise((resolve) => {
                    setTimeout(resolve, getRetryDelayMs);
                });
            }
        }

        if (!ualValidationPassed) {
            await this.handleError(
                operationId,
                blockchain,
                ualValidationError,
                ERROR_TYPE.GET.GET_VALIDATE_ASSET_ERROR,
            );
            return Command.empty();
        }

        const currentPeerId = this.networkModuleManager.getPeerId().toB58String();
        let paranetId;
        let repository = TRIPLE_STORE_REPOSITORIES.DKG;
        let migrationFlag = '0';
        const migrationFlagPath = path.join(process.cwd(), MIGRATION_FLAG_PATH);
        try {
            migrationFlag = await fs.readFile(migrationFlagPath, 'utf8');
            migrationFlag = migrationFlag.trim();
        } catch (error) {
            if (error.code === 'ENOENT') {
                this.logger.warn(
                    `Migration flag file not found at ${migrationFlagPath}, using default value '${migrationFlag}'`,
                );
            } else {
                throw error;
            }
        }
        if (paranetUAL) {
            const {
                blockchain: paranetBlockchain,
                contract: paranetContract,
                knowledgeCollectionId: paranetKnowledgeCollectionId,
                knowledgeAssetId: paranetKnowledgeAssetId,
            } = this.ualService.resolveUAL(paranetUAL);
            paranetId = this.paranetService.constructParanetId(
                paranetContract,
                paranetKnowledgeCollectionId,
                paranetKnowledgeAssetId,
            );

            if (!paranetSync && migrationFlag === '0') {
                // query the paranet repository if the migration is not yet finished
                repository = this.paranetService.getParanetRepositoryName(paranetUAL);
                const repositoryExists =
                    this.tripleStoreModuleManager.repositoryInitilized(repository);

                if (!repositoryExists) {
                    repository = TRIPLE_STORE_REPOSITORIES.DKG;
                }
            }

            const { isValid: paranetIsValid, errorMessage: paranetErrorMessage } =
                await this.validateParanet(
                    operationId,
                    paranetUAL,
                    paranetBlockchain,
                    paranetKnowledgeAssetId,
                    paranetNodesAccessPolicy,
                    paranetId,
                    knowledgeCollectionId,
                    blockchain,
                    contract,
                    ual,
                );
            if (!paranetIsValid) {
                await this.handleError(
                    operationId,
                    blockchain,
                    paranetErrorMessage,
                    ERROR_TYPE.GET.GET_VALIDATE_ASSET_ERROR,
                );
                return Command.empty();
            }
        }

        this.operationIdService.emitChangeEvent(
            OPERATION_ID_STATUS.GET.GET_VALIDATE_ASSET_END,
            operationId,
            blockchain,
        );

        await this.operationIdService.updateOperationIdStatus(
            operationId,
            blockchain,
            OPERATION_ID_STATUS.GET.GET_LOCAL_START,
        );
        let tokenIds;
        if (!knowledgeAssetId) {
            try {
                tokenIds = await this.blockchainModuleManager.getKnowledgeAssetsRange(
                    blockchain,
                    contract,
                    knowledgeCollectionId,
                );
            } catch (error) {
                // Asset created on old content asset storage contract
                tokenIds = {
                    startTokenId: 1,
                    endTokenId: 1,
                    burned: [],
                };
            }
        } else {
            // kaId is number, so transform it to range
            tokenIds = {
                startTokenId: knowledgeAssetId,
                endTokenId: knowledgeAssetId,
                burned: [],
            };
        }

        const promises = [];
        const assertionPromise = this.tripleStoreService.getAssertion(
            blockchain,
            contract,
            knowledgeCollectionId,
            knowledgeAssetId,
            tokenIds,
            migrationFlag,
            contentType,
            repository,
        );
        promises.push(assertionPromise);

        if (includeMetadata) {
            const metadataPromise = this.tripleStoreService.getAssertionMetadata(
                blockchain,
                contract,
                knowledgeCollectionId,
                repository,
            );
            promises.push(metadataPromise);
        }

        const [assertion, metadata] = await Promise.all(promises);

        const responseData = {
            assertion,
            ...(includeMetadata && metadata && { metadata }),
        };
        let localGetPassed = true;
        if (paranetNodesAccessPolicy === PARANET_ACCESS_POLICY.PERMISSIONED) {
            if (Array.isArray(assertion?.public)) {
                const assertionShouldHavePrivateTriples = assertion?.public?.some((triple) =>
                    triple.includes(`${PRIVATE_ASSERTION_PREDICATE}`),
                );
                if (assertionShouldHavePrivateTriples) {
                    localGetPassed = assertion?.private?.length > 0;
                }
            } else {
                localGetPassed = false;
            }
        }
        const localGetResultValid = await this.validateResponse(
            { assertion },
            blockchain,
            contract,
            knowledgeCollectionId,
            knowledgeAssetId,
            paranetNodesAccessPolicy,
            contentType,
        );
        if (
            localGetPassed &&
            localGetResultValid &&
            (assertion?.public?.length || assertion?.private?.length || assertion?.length)
        ) {
            await this.operationService.markOperationAsCompleted(
                operationId,
                blockchain,
                responseData,
                [
                    OPERATION_ID_STATUS.GET.GET_LOCAL_END,
                    OPERATION_ID_STATUS.GET.GET_END,
                    OPERATION_ID_STATUS.COMPLETED,
                ],
            );

            return Command.empty();
        }
        this.logger.debug(`Could not find asset with UAL: ${ual} locally`);

        try {
            const cachedResult = await this._tryCacheFallback(
                blockchain,
                contract,
                knowledgeCollectionId,
                knowledgeAssetId,
                ual,
                operationId,
                paranetNodesAccessPolicy,
                contentType,
            );
            if (cachedResult) {
                return cachedResult;
            }
        } catch (cacheErr) {
            this.logger.debug(
                `Pending storage cache fallback failed for ${ual}: ${cacheErr.message}`,
            );
        }

        await this.operationIdService.emitChangeEvent(
            OPERATION_ID_STATUS.GET.GET_LOCAL_END,
            operationId,
            blockchain,
        );

        await this.operationIdService.updateOperationIdStatus(
            operationId,
            blockchain,
            OPERATION_ID_STATUS.GET.GET_SHARD_START,
        );

        let nodesInfo = [];
        if (paranetNodesAccessPolicy === PARANET_ACCESS_POLICY.PERMISSIONED) {
            const onChainNodes = await this.blockchainModuleManager.getPermissionedNodes(
                blockchain,
                paranetId,
            );
            const foundNodes = await Promise.all(
                onChainNodes.map(async (node) =>
                    this.shardingTableService.findPeerAddressAndProtocols(
                        this.cryptoService.convertHexToAscii(node.nodeId),
                    ),
                ),
            );
            const networkProtocols = this.operationService.getNetworkProtocols();

            for (const node of foundNodes) {
                if (node.id !== currentPeerId) {
                    nodesInfo.push({ id: node.id, protocol: networkProtocols[0] });
                }
            }
        } else {
            nodesInfo = await this.findShardNodes(operationId, blockchain, currentPeerId);
        }

        this.minAckResponses = this.operationService.getMinAckResponses(
            minimumNumberOfNodeReplications,
        );

        if (nodesInfo.length < this.minAckResponses) {
            await this.handleError(
                operationId,
                blockchain,
                `Unable to find enough nodes for operationId: ${operationId}. Minimum number of nodes required: ${this.minAckResponses}`,
                ERROR_TYPE.FIND_SHARD.GET_FIND_SHARD_ERROR,
                true,
            );
            return Command.empty();
        }

        await this.operationIdService.updateOperationIdStatus(
            operationId,
            blockchain,
            OPERATION_ID_STATUS.GET.GET_SHARD_END,
        );

        const message = {
            blockchain,
            contract,
            knowledgeCollectionId,
            knowledgeAssetId,
            tokenIds,
            includeMetadata,
            ual,
            paranetUAL,
            migrationFlag,
            repository,
        };
        const BATCH_SIZE = 5;
        let index = 0;

        // Process shard nodes in batches
        while (index < nodesInfo.length) {
            // Slice out a batch of nodes
            const batch = nodesInfo.slice(index, index + BATCH_SIZE);

            // Send messages in parallel to all nodes in the current batch
            // eslint-disable-next-line no-await-in-loop
            const results = await Promise.all(
                batch.map((node) => this.sendMessage(node, operationId, message)),
            );

            const succsesfulResult = [];
            const failedResults = [];

            results.forEach((result) => {
                if (result.success) {
                    succsesfulResult.push(result);
                } else {
                    failedResults.push(result);
                }
            });

            for (const result of succsesfulResult) {
                // eslint-disable-next-line no-await-in-loop
                const isResponseValid = await this.validateResponse(
                    result.responseData,
                    blockchain,
                    contract,
                    knowledgeCollectionId,
                    knowledgeAssetId,
                    paranetNodesAccessPolicy,
                    contentType,
                );
                if (isResponseValid) {
                    this.operationService.markOperationAsCompleted(
                        operationId,
                        blockchain,
                        result.responseData,
                        [OPERATION_ID_STATUS.GET.GET_END, OPERATION_ID_STATUS.COMPLETED],
                    );
                    return Command.empty();
                }
            }
            // Otherwise, continue with the next batch
            index += BATCH_SIZE;
        }

        await this.handleError(
            operationId,
            blockchain,
            `No node responded successfully for GET for ${ual}. Minimum required responses: ${this.minAckResponses}. Operation id: ${operationId}`,
            ERROR_TYPE.FIND_SHARD.GET_ERROR,
        );

        return Command.empty();
    }

    async _tryCacheFallback(
        blockchain,
        contract,
        knowledgeCollectionId,
        knowledgeAssetId,
        ual,
        operationId,
        paranetNodesAccessPolicy,
        contentType,
    ) {
        if (knowledgeAssetId) return null;

        const latestMerkleRoot =
            await this.blockchainModuleManager.getKnowledgeCollectionLatestMerkleRoot(
                blockchain,
                contract,
                knowledgeCollectionId,
            );
        if (!latestMerkleRoot) return null;

        const publishOpId = this.pendingStorageService.getOperationIdByMerkleRoot(latestMerkleRoot);
        if (!publishOpId) return null;

        const cachedAssertion = await this.pendingStorageService.getCachedDataset(publishOpId);
        if (
            !cachedAssertion ||
            (!cachedAssertion.public?.length && !cachedAssertion.private?.length)
        ) {
            return null;
        }

        const filteredAssertion = this._filterAssertionByContentType(cachedAssertion, contentType);
        if (!filteredAssertion.public?.length && !filteredAssertion.private?.length) {
            return null;
        }

        let cachePassed = true;
        if (paranetNodesAccessPolicy === PARANET_ACCESS_POLICY.PERMISSIONED) {
            if (Array.isArray(filteredAssertion.public)) {
                const shouldHavePrivate = filteredAssertion.public.some((triple) =>
                    triple.includes(`${PRIVATE_ASSERTION_PREDICATE}`),
                );
                if (shouldHavePrivate) {
                    cachePassed = filteredAssertion.private?.length > 0;
                }
            } else {
                cachePassed = false;
            }
        }

        if (!cachePassed) return null;

        const cachedResponseData = { assertion: filteredAssertion };
        const isValid = await this.validateResponse(
            cachedResponseData,
            blockchain,
            contract,
            knowledgeCollectionId,
            knowledgeAssetId,
            paranetNodesAccessPolicy,
            contentType,
        );
        if (!isValid) return null;

        this.logger.info(
            `Serving asset ${ual} from pending storage cache (merkleRoot: ${latestMerkleRoot})`,
        );
        await this.operationService.markOperationAsCompleted(
            operationId,
            blockchain,
            cachedResponseData,
            [
                OPERATION_ID_STATUS.GET.GET_LOCAL_END,
                OPERATION_ID_STATUS.GET.GET_END,
                OPERATION_ID_STATUS.COMPLETED,
            ],
        );
        return Command.empty();
    }

    _filterAssertionByContentType(assertion, contentType) {
        if (!contentType || contentType === 'all') return assertion;
        if (contentType === 'public') {
            return { public: assertion.public || [] };
        }
        if (contentType === 'private') {
            return { private: assertion.private || [] };
        }
        return assertion;
    }

    async validateUAL(operationId, blockchain, contract, knowledgeCollectionId, ual) {
        const isUAL = this.ualService.isUAL(ual);

        if (!isUAL) {
            return {
                isValid: false,
                errorMessage: `Get for operation id: ${operationId}, UAL: ${ual}: is not a UAL.`,
            };
        }

        const isValidUal = await this.validationService.validateUal(
            blockchain,
            contract,
            knowledgeCollectionId,
        );

        if (!isValidUal) {
            return {
                isValid: false,
                errorMessage: `Get for operation id: ${operationId}, UAL: ${ual}: there is no asset with this UAL.`,
            };
        }
        return {
            isValid: true,
            errorMessage: null,
        };
    }

    async validateParanet(
        operationId,
        paranetUAL,
        paranetBlockchain,
        paranetKnowledgeAssetId,
        paranetNodeAccessPolicy,
        paranetId,
        knowledgeCollectionId,
        blockchain,
        contract,
        ual,
    ) {
        if (!paranetKnowledgeAssetId) {
            return {
                isValid: false,
                errorMessage: `Invalid paranet UAL: ${paranetUAL} . Paranet knowledge asset token id is required!`,
            };
        }
        const isParanetUAL = this.ualService.isUAL(paranetUAL);

        if (!isParanetUAL) {
            return {
                isValid: false,
                errorMessage: `Get for operation id: ${operationId}, Paranet UAL: ${paranetUAL}: is not a UAL.`,
            };
        }

        const [paranetExists, chainParanetNodesAccessPolicy] = await Promise.all([
            this.blockchainModuleManager.paranetExists(paranetBlockchain, paranetId),
            this.blockchainModuleManager.getNodesAccessPolicy(paranetBlockchain, paranetId),
        ]);

        const knowledgeCollectionOnchainId = this.cryptoService.keccak256EncodePacked(
            ['address', 'uint256'],
            [contract, knowledgeCollectionId],
        );
        const paranetContainsKnowledgeCollection =
            await this.blockchainModuleManager.isKnowledgeCollectionRegistered(
                blockchain,
                paranetId,
                knowledgeCollectionOnchainId,
            );
        if (!paranetContainsKnowledgeCollection) {
            return {
                isValid: false,
                errorMessage: `Paranet UAL: ${paranetUAL} does not contain Knowledge Collection: ${ual}`,
            };
        }

        if (!paranetExists) {
            return {
                isValid: false,
                errorMessage: `Get for operation id: ${operationId}, Paranet UAL: ${paranetUAL}: paranet does not exist.`,
            };
        }

        if (paranetNodeAccessPolicy !== chainParanetNodesAccessPolicy) {
            return {
                isValid: false,
                errorMessage: `Get for operation id: ${operationId}, Paranet UAL: ${paranetUAL}: onchain paranet access policy does not match the requested paranet access policy.`,
            };
        }

        return {
            isValid: true,
            errorMessage: null,
        };
    }

    async findShardNodes(operationId, blockchain, currentPeerId) {
        this.logger.debug(`Searching for shard for operationId: ${operationId}`);

        const networkProtocols = this.operationService.getNetworkProtocols();

        const shardNodes = await this.shardingTableService.findShard(blockchain, true);

        // TODO: Optimize this so it's returned by shardingTableService.findShard
        const foundNodes = await Promise.all(
            shardNodes.map(({ peerId }) =>
                this.shardingTableService.findPeerAddressAndProtocols(peerId),
            ),
        );
        const nodesInfo = [];
        for (const node of foundNodes) {
            if (node.id !== currentPeerId) {
                nodesInfo.push({ id: node.id, protocol: networkProtocols[0] });
            }
        }

        this.logger.debug(`Found ${nodesInfo.length} node(s) for operationId: ${operationId}`);
        this.logger.trace(
            `Found shard: ${JSON.stringify(
                nodesInfo.map((node) => node.id),
                null,
                2,
            )}`,
        );
        return nodesInfo;
    }

    async sendMessage(node, operationId, message) {
        const response = await this.messagingService.sendProtocolMessage(
            node,
            operationId,
            message,
            NETWORK_MESSAGE_TYPES.REQUESTS.PROTOCOL_REQUEST,
            NETWORK_MESSAGE_TIMEOUT_MILLS.GET.REQUEST,
        );
        return {
            success: response.header.messageType === NETWORK_MESSAGE_TYPES.RESPONSES.ACK,
            responseData: response.data,
        };
    }

    async validateResponse(
        responseData,
        blockchain,
        contract,
        knowledgeCollectionId,
        knowledgeAssetId,
        paranetNodesAccessPolicy,
        contentType,
    ) {
        if (knowledgeAssetId) {
            return true;
        }
        if (responseData?.assertion?.public) {
            // We can only validate whole collection not particular KA
            if (
                !knowledgeAssetId ||
                (typeof knowledgeAssetId === 'object' &&
                    Object.keys(knowledgeAssetId).length === 3 &&
                    'startTokenId' in knowledgeAssetId &&
                    'endTokenId' in knowledgeAssetId &&
                    'burned' in knowledgeAssetId &&
                    Array.isArray(knowledgeAssetId.burned))
            ) {
                const publicAssertion = responseData?.assertion?.public;

                const filteredPublic = [];
                const privateHashTriples = [];
                publicAssertion.forEach((triple) => {
                    if (triple.startsWith(`<${PRIVATE_HASH_SUBJECT_PREFIX}`)) {
                        privateHashTriples.push(triple);
                    } else {
                        filteredPublic.push(triple);
                    }
                });

                const publicKnowledgeAssetsTriplesGrouped = kcTools.groupNquadsBySubject(
                    filteredPublic,
                    true,
                );
                publicKnowledgeAssetsTriplesGrouped.push(
                    ...kcTools.groupNquadsBySubject(privateHashTriples, true),
                );

                try {
                    await this.validationService.validateDatasetOnBlockchain(
                        publicKnowledgeAssetsTriplesGrouped.map((t) => t.sort()).flat(),
                        blockchain,
                        contract,
                        knowledgeCollectionId,
                    );

                    if (paranetNodesAccessPolicy === PARANET_ACCESS_POLICY.PERMISSIONED) {
                        if (Array.isArray(responseData?.assertion?.public)) {
                            const assertionShouldHavePrivateTriples =
                                responseData?.assertion?.public?.some((triple) =>
                                    triple.includes(`${PRIVATE_ASSERTION_PREDICATE}`),
                                );
                            if (assertionShouldHavePrivateTriples) {
                                if (responseData?.assertion?.private?.length > 0) {
                                    await this.validationService.validatePrivateMerkleRoot(
                                        responseData.assertion.public,
                                        responseData.assertion.private,
                                    );
                                    return true;
                                }
                            }
                        }
                        return false;
                    }

                    if (responseData.assertion?.private?.length) {
                        await this.validationService.validatePrivateMerkleRoot(
                            responseData.assertion.public,
                            responseData.assertion.private,
                        );
                        return true;
                    }
                } catch (e) {
                    return false;
                }
            }

            return true;
        }
        if (
            !responseData?.assertion?.public &&
            responseData?.assertion?.private &&
            contentType === 'private'
        ) {
            // if there is only private part skip validation
            return true;
        }

        return false;
    }

    /**
     * Builds default GetCommand
     * @param map
     * @returns {{add, data: *, delay: *, deadline: *}}
     */
    default(map) {
        const command = {
            name: 'getCommand',
            transactional: false,
            priority: COMMAND_PRIORITY.HIGH,
        };
        Object.assign(command, map);
        return command;
    }
}

export default GetCommand;
